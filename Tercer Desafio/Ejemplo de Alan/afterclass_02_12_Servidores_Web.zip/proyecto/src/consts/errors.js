export const ERRORS = {
  VALIDATION_ERROR: "Validation error",
  NOT_FOUND_ERROR: "Not found error",
};
